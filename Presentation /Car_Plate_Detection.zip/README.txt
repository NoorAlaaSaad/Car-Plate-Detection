This is an Overleaf-ready LaTeX project.

- Open `main.tex` in Overleaf (or upload this whole folder as a ZIP).
- Compile with pdfLaTeX.
- All images are under `images/`.
